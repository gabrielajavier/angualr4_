import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
/* PRIMER EJERCICIO */
/*export class AppComponent {
  title = 'PlatziSquare';
  a = 3;
  b = 5;
  listo = false;
  nombre:string= '';
  apellido:string= '';
  edad:string= '';

  constructor(){
  	setTimeout(() =>{
  		this.listo = true;
  	}, 3000)
  }

  hacerAlgo(){
  	alert('Haciendo Algo');
  }
}*/

/* SEGUNDO EJERCICIO */


/* EJERCICIO MAYORES DE 18 */
/*export class AppComponent {
  title = 'PlatziSquare';
  personas: any = [
    {nombre:'María', edad:'14'},
    {nombre:'Fernando', edad:'25'},
    {nombre:'Elena', edad:'30'},
    {nombre:'Elizabeth', edad:'18'},
    {nombre:'Paola', edad:'20'},
    {nombre:'Gracia', edad:'19'},
    {nombre:'Belén', edad:'10'},
    {nombre:'Rosa', edad:'22'},
    {nombre:'Joselyn', edad:'17'},
  ];
  constructor(){
  }
}*/